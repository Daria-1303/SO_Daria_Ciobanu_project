#ifndef __MANAGE_ARGV_H__
#define __MANAGE_ARGV_H__

#include "../../treasure_manager.h"

Operation_T read_argv(int argc, char **argv);
void print_help();

#endif