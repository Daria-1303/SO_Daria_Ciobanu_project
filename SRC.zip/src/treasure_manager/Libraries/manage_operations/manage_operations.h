#ifndef __MANAGE_OPERATIONS_H__
#define __MANAGE_OPERATIONS_H__

#include "add/add.h"
#include "list/list.h"
#include "remove/remove.h"

#endif