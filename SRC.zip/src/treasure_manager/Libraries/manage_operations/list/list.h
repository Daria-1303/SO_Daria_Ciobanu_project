#ifndef __LIST_H__
#define __LIST_H__

#include "../../../treasure_manager.h"
#include "../../helper_functions/utils.h"

void list_treasure(const char *hunt_id);
void view(const char *hunt_id, const char *id);

#endif