#ifndef __ADD_H__
#define __ADD_H__

#include "../../../treasure_manager.h"
#include "../../helper_functions/utils.h"

void add_treasure(const char *hunt_id);

#endif