#ifndef __MANAGE_OPERATIONS_H__
#define __MANAGE_OPERATIONS_H__

#include "add/add.h"

#endif